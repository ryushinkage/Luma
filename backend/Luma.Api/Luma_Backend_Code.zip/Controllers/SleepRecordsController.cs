using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Luma.Api.Data;
using Luma.Api.Models;

namespace Luma.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class SleepRecordsController : ControllerBase
{
    private readonly AppDbContext _context;

    public SleepRecordsController(AppDbContext context)
    {
        _context = context;
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] SleepRecord record)
    {
        if (record.UserId == Guid.Empty) return BadRequest("UserId ����'�������.");

        record.Id = Guid.NewGuid();
        _context.SleepRecords.Add(record);
        await _context.SaveChangesAsync();

        return Ok(new { message = "����� ��� ���������!", recordId = record.Id });
    }

    [HttpGet("user/{userId}")]
    public async Task<IActionResult> GetUserRecords(Guid userId)
    {
        var records = await _context.SleepRecords
            .Where(r => r.UserId == userId)
            .ToListAsync();

        return Ok(records);
    }
}