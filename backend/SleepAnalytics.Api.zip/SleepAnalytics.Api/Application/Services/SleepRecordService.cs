using Microsoft.EntityFrameworkCore;
using SleepAnalytics.Api.Application.Dtos;
using SleepAnalytics.Api.Domain.Entities;
using SleepAnalytics.Api.Infrastructure.Persistence;

namespace SleepAnalytics.Api.Application.Services;

public interface ISleepRecordService
{
    Task<Result<SleepRecordResponse>> CreateAsync(Guid userId, CreateSleepRecordRequest req, CancellationToken ct = default);
    Task<Result<SleepRecordResponse>> UpdateAsync(Guid userId, Guid recordId, UpdateSleepRecordRequest req, CancellationToken ct = default);
    Task<Result<bool>> DeleteAsync(Guid userId, Guid recordId, CancellationToken ct = default);
    Task<IReadOnlyList<SleepRecordResponse>> ListAsync(Guid userId, DateOnly? from, DateOnly? to, CancellationToken ct = default);
    Task<SleepStatsResponse> GetStatsAsync(Guid userId, DateOnly from, DateOnly to, CancellationToken ct = default);
}

public class SleepRecordService : ISleepRecordService
{
    // BR07: sane upper bound for a single sleep interval.
    private const int MaxSleepMinutes = 18 * 60;

    private readonly AppDbContext _db;
    public SleepRecordService(AppDbContext db) => _db = db;

    public async Task<Result<SleepRecordResponse>> CreateAsync(Guid userId, CreateSleepRecordRequest req, CancellationToken ct = default)
    {
        var validation = ValidateInterval(req.SleepStart, req.SleepEnd);
        if (validation is not null)
            return Result<SleepRecordResponse>.Fail(validation);

        var duration = ComputeDurationMinutes(req.SleepStart, req.SleepEnd);
        var target = await GetTargetSleepMinutesAsync(userId, ct);

        var record = new SleepRecord
        {
            UserId = userId,
            SleepStart = req.SleepStart,
            SleepEnd = req.SleepEnd,
            SleepDate = DateOnly.FromDateTime(req.SleepEnd),  // local sleep date = wake day
            DurationMinutes = duration,
            PerceivedQuality = req.PerceivedQuality,
            Notes = req.Notes
        };

        if (req.Factor is not null)
            record.Factor = MapFactor(req.Factor);

        record.Metric = BuildMetric(record, target);   // BR08/BR09/BR12 recalculation

        _db.SleepRecords.Add(record);
        await _db.SaveChangesAsync(ct);

        return Result<SleepRecordResponse>.Ok(ToResponse(record));
    }

    public async Task<Result<SleepRecordResponse>> UpdateAsync(Guid userId, Guid recordId, UpdateSleepRecordRequest req, CancellationToken ct = default)
    {
        // BR04: a user can only modify their own records.
        var record = await _db.SleepRecords
            .Include(r => r.Factor)
            .Include(r => r.Metric)
            .FirstOrDefaultAsync(r => r.Id == recordId && r.UserId == userId, ct);

        if (record is null)
            return Result<SleepRecordResponse>.Fail("Sleep record not found.");

        var validation = ValidateInterval(req.SleepStart, req.SleepEnd);
        if (validation is not null)
            return Result<SleepRecordResponse>.Fail(validation);

        record.SleepStart = req.SleepStart;
        record.SleepEnd = req.SleepEnd;
        record.SleepDate = DateOnly.FromDateTime(req.SleepEnd);
        record.DurationMinutes = ComputeDurationMinutes(req.SleepStart, req.SleepEnd);
        record.PerceivedQuality = req.PerceivedQuality;
        record.Notes = req.Notes;
        record.UpdatedAt = DateTime.UtcNow;

        if (req.Factor is not null)
        {
            record.Factor ??= new SleepFactor { SleepRecordId = record.Id };
            record.Factor.Caffeine = req.Factor.Caffeine;
            record.Factor.StressLevel = req.Factor.StressLevel;
            record.Factor.ScreenTimeMinutes = req.Factor.ScreenTimeMinutes;
            record.Factor.PhysicalActivityMinutes = req.Factor.PhysicalActivityMinutes;
            record.Factor.Notes = req.Factor.Notes;
        }

        // BR08: recalculate dependent metrics after the change.
        var target = await GetTargetSleepMinutesAsync(userId, ct);
        record.Metric ??= new SleepMetric { SleepRecordId = record.Id };
        ApplyMetric(record.Metric, record, target);

        await _db.SaveChangesAsync(ct);
        return Result<SleepRecordResponse>.Ok(ToResponse(record));
    }

    public async Task<Result<bool>> DeleteAsync(Guid userId, Guid recordId, CancellationToken ct = default)
    {
        var record = await _db.SleepRecords
            .FirstOrDefaultAsync(r => r.Id == recordId && r.UserId == userId, ct);

        if (record is null)
            return Result<bool>.Fail("Sleep record not found.");

        _db.SleepRecords.Remove(record);   // cascade removes factor + metric (BR08)
        await _db.SaveChangesAsync(ct);
        return Result<bool>.Ok(true);
    }

    public async Task<IReadOnlyList<SleepRecordResponse>> ListAsync(Guid userId, DateOnly? from, DateOnly? to, CancellationToken ct = default)
    {
        // BR04: filter strictly by authenticated user identity.
        var query = _db.SleepRecords
            .Include(r => r.Factor)
            .Where(r => r.UserId == userId);

        if (from is not null) query = query.Where(r => r.SleepDate >= from);
        if (to is not null) query = query.Where(r => r.SleepDate <= to);

        var records = await query.OrderByDescending(r => r.SleepDate).ToListAsync(ct);
        return records.Select(ToResponse).ToList();
    }

    public async Task<SleepStatsResponse> GetStatsAsync(Guid userId, DateOnly from, DateOnly to, CancellationToken ct = default)
    {
        var records = await _db.SleepRecords
            .Include(r => r.Metric)
            .Where(r => r.UserId == userId && r.SleepDate >= from && r.SleepDate <= to)
            .ToListAsync(ct);

        if (records.Count == 0)
            return new SleepStatsResponse(0, 0, 0);

        var avg = records.Average(r => r.DurationMinutes);
        var debt = records.Sum(r => r.Metric?.SleepDebtMinutes ?? 0);  // BR12
        return new SleepStatsResponse(records.Count, Math.Round(avg, 1), debt);
    }

    // ---- helpers ----

    // BR07: validate a logically consistent interval.
    private static string? ValidateInterval(DateTime start, DateTime end)
    {
        if (end <= start)
            return "Wake-up time must be later than sleep start time.";
        var minutes = (end - start).TotalMinutes;
        if (minutes > MaxSleepMinutes)
            return $"Sleep interval exceeds the allowed maximum of {MaxSleepMinutes / 60} hours.";
        return null;
    }

    // BR09: duration in minutes (overnight handled because both are full datetimes).
    private static int ComputeDurationMinutes(DateTime start, DateTime end)
        => (int)Math.Round((end - start).TotalMinutes);

    private async Task<int> GetTargetSleepMinutesAsync(Guid userId, CancellationToken ct)
    {
        var profile = await _db.UserProfiles.FirstOrDefaultAsync(p => p.UserId == userId, ct);
        return profile?.TargetSleepMinutes ?? 480;  // BR12 default target
    }

    private static SleepFactor MapFactor(SleepFactorDto dto) => new()
    {
        Caffeine = dto.Caffeine,
        StressLevel = dto.StressLevel,
        ScreenTimeMinutes = dto.ScreenTimeMinutes,
        PhysicalActivityMinutes = dto.PhysicalActivityMinutes,
        Notes = dto.Notes
    };

    private static SleepMetric BuildMetric(SleepRecord record, int target)
    {
        var metric = new SleepMetric { SleepRecordId = record.Id };
        ApplyMetric(metric, record, target);
        return metric;
    }

    private static void ApplyMetric(SleepMetric metric, SleepRecord record, int target)
    {
        // BR12: daily sleep debt = max(0, target - actual).
        metric.SleepDebtMinutes = Math.Max(0, target - record.DurationMinutes);
        metric.EfficiencyScore = record.SleepEfficiency.HasValue
            ? record.SleepEfficiency * 100f
            : null;
        // BR10: quality estimate is limited when phase/efficiency data is missing.
        metric.IsLimited = record.SleepEfficiency is null;
        metric.QualityScore = record.PerceivedQuality.HasValue
            ? record.PerceivedQuality * 10f
            : null;
    }

    private static SleepRecordResponse ToResponse(SleepRecord r) => new(
        r.Id, r.SleepDate, r.SleepStart, r.SleepEnd, r.DurationMinutes,
        r.PerceivedQuality, r.Notes,
        r.Factor is null ? null : new SleepFactorDto(
            r.Factor.Caffeine, r.Factor.StressLevel, r.Factor.ScreenTimeMinutes,
            r.Factor.PhysicalActivityMinutes, r.Factor.Notes));
}
