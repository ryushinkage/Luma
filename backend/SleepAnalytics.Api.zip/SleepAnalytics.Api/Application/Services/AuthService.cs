using Microsoft.EntityFrameworkCore;
using SleepAnalytics.Api.Application.Dtos;
using SleepAnalytics.Api.Domain.Entities;
using SleepAnalytics.Api.Domain.Enums;
using SleepAnalytics.Api.Infrastructure.Integrations;
using SleepAnalytics.Api.Infrastructure.Persistence;

namespace SleepAnalytics.Api.Application.Services;

public interface IAuthService
{
    Task<Result<AuthResponse>> LoginWithGoogleAsync(GoogleLoginRequest request, CancellationToken ct = default);
}

public class AuthService : IAuthService
{
    private readonly AppDbContext _db;
    private readonly IGoogleAuthService _google;
    private readonly ITokenService _tokens;

    public AuthService(AppDbContext db, IGoogleAuthService google, ITokenService tokens)
    {
        _db = db;
        _google = google;
        _tokens = tokens;
    }

    // BR01: registration/login only via Google OAuth; reuse account if it exists.
    // BR02: new accounts get the User role by default.
    public async Task<Result<AuthResponse>> LoginWithGoogleAsync(GoogleLoginRequest request, CancellationToken ct = default)
    {
        var identity = await _google.VerifyAsync(request.IdToken, ct);
        if (identity is null)
            return Result<AuthResponse>.Fail("Google authentication failed.");

        var user = await _db.Users
            .FirstOrDefaultAsync(u => u.GoogleSubjectId == identity.Subject, ct);

        if (user is null)
        {
            user = new User
            {
                GoogleSubjectId = identity.Subject,
                Email = identity.Email,
                Name = identity.Name,
                Role = UserRole.User,
                Profile = new UserProfile(),
                Subscription = new Subscription(),          // defaults to Free
                NotificationSettings = new NotificationSettings()
            };
            _db.Users.Add(user);
            await _db.SaveChangesAsync(ct);
        }

        if (user.IsBlocked)
            return Result<AuthResponse>.Fail("Account is blocked.");

        var token = _tokens.CreateToken(user);
        return Result<AuthResponse>.Ok(new AuthResponse(token, user.Id, user.Email, user.Role));
    }
}
