namespace SleepAnalytics.Api.Application.Services;

// Lightweight result wrapper so services can signal validation failures (BR07)
// without throwing, and controllers can map them to proper HTTP codes.
public class Result<T>
{
    public bool Succeeded { get; private init; }
    public T? Value { get; private init; }
    public string? Error { get; private init; }

    public static Result<T> Ok(T value) => new() { Succeeded = true, Value = value };
    public static Result<T> Fail(string error) => new() { Succeeded = false, Error = error };
}
