using SleepAnalytics.Api.Domain.Enums;

namespace SleepAnalytics.Api.Application.Dtos;

// ---- Auth ----
public record GoogleLoginRequest(string IdToken);
public record AuthResponse(string Token, Guid UserId, string Email, UserRole Role);

// ---- Sleep records ----
public record SleepFactorDto(
    bool Caffeine,
    int? StressLevel,
    int? ScreenTimeMinutes,
    int? PhysicalActivityMinutes,
    string? Notes);

public record CreateSleepRecordRequest(
    DateTime SleepStart,
    DateTime SleepEnd,
    int? PerceivedQuality,
    string? Notes,
    SleepFactorDto? Factor);

public record UpdateSleepRecordRequest(
    DateTime SleepStart,
    DateTime SleepEnd,
    int? PerceivedQuality,
    string? Notes,
    SleepFactorDto? Factor);

public record SleepRecordResponse(
    Guid Id,
    DateOnly SleepDate,
    DateTime SleepStart,
    DateTime SleepEnd,
    int DurationMinutes,
    int? PerceivedQuality,
    string? Notes,
    SleepFactorDto? Factor);

public record SleepStatsResponse(
    int RecordCount,
    double AverageDurationMinutes,
    int TotalSleepDebtMinutes);
