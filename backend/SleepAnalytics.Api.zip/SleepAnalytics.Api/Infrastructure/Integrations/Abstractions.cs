namespace SleepAnalytics.Api.Infrastructure.Integrations;

// ---- Google OAuth (BR01) ----
public record GoogleIdentity(string Subject, string Email, string Name);

public interface IGoogleAuthService
{
    // Verifies a Google ID token / auth code and returns the verified identity.
    Task<GoogleIdentity?> VerifyAsync(string idToken, CancellationToken ct = default);
}

// ---- Payments / PayPal (BR24) ----
public record PaymentConfirmation(bool Success, string PaymentReference, DateTime? ExpiresAt);

public interface IPaymentService
{
    Task<PaymentConfirmation> ConfirmSubscriptionAsync(string orderId, CancellationToken ct = default);
    Task<bool> CancelSubscriptionAsync(string paymentReference, CancellationToken ct = default);
}

// ---- AI API (BR19/BR20) ----
public record AiReportResult(string Summary, string Insights);

public interface IAiService
{
    Task<AiReportResult> GenerateReportAsync(string userContextJson, CancellationToken ct = default);
}

// ---- Push notifications (BR26) ----
public interface IPushNotificationService
{
    Task SendAsync(Guid userId, string title, string body, CancellationToken ct = default);
}
