using Microsoft.Extensions.Logging;

namespace SleepAnalytics.Api.Infrastructure.Integrations;

// NOTE: These are stubs for the MVP scaffold. Replace with real SDK calls.

public class StubGoogleAuthService : IGoogleAuthService
{
    public Task<GoogleIdentity?> VerifyAsync(string idToken, CancellationToken ct = default)
    {
        // TODO: validate token via Google.Apis.Auth.GoogleJsonWebSignature.ValidateAsync.
        // Stub treats the token string as the subject id for local development.
        if (string.IsNullOrWhiteSpace(idToken))
            return Task.FromResult<GoogleIdentity?>(null);

        var identity = new GoogleIdentity(
            Subject: $"google-{idToken}",
            Email: $"{idToken}@example.com",
            Name: "Test User");
        return Task.FromResult<GoogleIdentity?>(identity);
    }
}

public class StubPaymentService : IPaymentService
{
    public Task<PaymentConfirmation> ConfirmSubscriptionAsync(string orderId, CancellationToken ct = default)
    {
        // TODO: verify PayPal order via PayPal REST SDK / webhook signature.
        var confirmation = new PaymentConfirmation(
            Success: !string.IsNullOrWhiteSpace(orderId),
            PaymentReference: $"pp-{orderId}",
            ExpiresAt: DateTime.UtcNow.AddDays(30));
        return Task.FromResult(confirmation);
    }

    public Task<bool> CancelSubscriptionAsync(string paymentReference, CancellationToken ct = default)
        => Task.FromResult(true);
}

public class StubAiService : IAiService
{
    public Task<AiReportResult> GenerateReportAsync(string userContextJson, CancellationToken ct = default)
    {
        // TODO: call OpenAI / Gemini API with a controlled system prompt.
        var result = new AiReportResult(
            Summary: "Stub summary: sleep was mostly regular this period.",
            Insights: "Stub insight: consider a more stable wake-up window. " +
                      "This is informational guidance, not a medical diagnosis.");
        return Task.FromResult(result);
    }
}

public class StubPushNotificationService : IPushNotificationService
{
    private readonly ILogger<StubPushNotificationService> _logger;
    public StubPushNotificationService(ILogger<StubPushNotificationService> logger) => _logger = logger;

    public Task SendAsync(Guid userId, string title, string body, CancellationToken ct = default)
    {
        _logger.LogInformation("[StubPush] -> {UserId}: {Title} / {Body}", userId, title, body);
        return Task.CompletedTask;
    }
}
