using Microsoft.EntityFrameworkCore;
using SleepAnalytics.Api.Domain.Entities;

namespace SleepAnalytics.Api.Infrastructure.Persistence;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<User> Users => Set<User>();
    public DbSet<UserProfile> UserProfiles => Set<UserProfile>();
    public DbSet<Subscription> Subscriptions => Set<Subscription>();
    public DbSet<NotificationSettings> NotificationSettings => Set<NotificationSettings>();
    public DbSet<SleepRecord> SleepRecords => Set<SleepRecord>();
    public DbSet<SleepFactor> SleepFactors => Set<SleepFactor>();
    public DbSet<SleepMetric> SleepMetrics => Set<SleepMetric>();
    public DbSet<AIReport> AIReports => Set<AIReport>();
    public DbSet<Recommendation> Recommendations => Set<Recommendation>();
    public DbSet<RiskIndicator> RiskIndicators => Set<RiskIndicator>();
    public DbSet<RecommendationRule> RecommendationRules => Set<RecommendationRule>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        // Enums stored as strings for readability in PostgreSQL.
        b.Entity<User>(e =>
        {
            e.HasIndex(u => u.GoogleSubjectId).IsUnique();   // BR01 stable identity key
            e.Property(u => u.Role).HasConversion<string>();
            e.HasOne(u => u.Profile).WithOne(p => p.User!)
                .HasForeignKey<UserProfile>(p => p.UserId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(u => u.Subscription).WithOne(s => s.User!)
                .HasForeignKey<Subscription>(s => s.UserId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(u => u.NotificationSettings).WithOne(n => n.User!)
                .HasForeignKey<NotificationSettings>(n => n.UserId).OnDelete(DeleteBehavior.Cascade);
        });

        b.Entity<Subscription>(e =>
        {
            e.Property(s => s.PlanType).HasConversion<string>();
            e.Property(s => s.Status).HasConversion<string>();
        });

        b.Entity<SleepRecord>(e =>
        {
            e.HasIndex(r => new { r.UserId, r.SleepDate });
            e.HasOne(r => r.Factor).WithOne(f => f.SleepRecord!)
                .HasForeignKey<SleepFactor>(f => f.SleepRecordId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(r => r.Metric).WithOne(m => m.SleepRecord!)
                .HasForeignKey<SleepMetric>(m => m.SleepRecordId).OnDelete(DeleteBehavior.Cascade);
        });

        b.Entity<AIReport>(e =>
        {
            e.HasMany(r => r.Recommendations).WithOne(x => x.Report!)
                .HasForeignKey(x => x.ReportId).OnDelete(DeleteBehavior.Cascade);
            e.HasMany(r => r.RiskIndicators).WithOne(x => x.Report!)
                .HasForeignKey(x => x.ReportId).OnDelete(DeleteBehavior.Cascade);
        });

        b.Entity<Recommendation>().Property(r => r.Type).HasConversion<string>();
        b.Entity<RiskIndicator>().Property(r => r.Level).HasConversion<string>();
    }
}
