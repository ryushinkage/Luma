namespace SleepAnalytics.Api.Domain.Enums;

public enum UserRole { User, Admin }

public enum PlanType { Free, Premium }

public enum SubscriptionStatus { Active, Expired, Cancelled }

public enum RiskLevel { Low, Medium, High }

public enum RecommendationType { SleepMode, Habit, Stress, Activity }
