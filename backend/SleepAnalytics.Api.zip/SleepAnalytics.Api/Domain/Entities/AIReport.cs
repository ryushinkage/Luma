namespace SleepAnalytics.Api.Domain.Entities;

// BR20: periodic AI report summary.
public class AIReport
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid UserId { get; set; }

    public DateOnly PeriodStart { get; set; }
    public DateOnly PeriodEnd { get; set; }
    public string Summary { get; set; } = string.Empty;
    public string? Insights { get; set; }

    // BR20: flagged when the period had insufficient data.
    public bool IsLimitedData { get; set; }
    public DateTime GeneratedAt { get; set; } = DateTime.UtcNow;

    public User? User { get; set; }
    public ICollection<Recommendation> Recommendations { get; set; } = new List<Recommendation>();
    public ICollection<RiskIndicator> RiskIndicators { get; set; } = new List<RiskIndicator>();
}
