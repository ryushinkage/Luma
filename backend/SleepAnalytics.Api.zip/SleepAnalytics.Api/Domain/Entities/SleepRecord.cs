namespace SleepAnalytics.Api.Domain.Entities;

public class SleepRecord
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid UserId { get; set; }

    public DateOnly SleepDate { get; set; }
    public DateTime SleepStart { get; set; }
    public DateTime SleepEnd { get; set; }

    // BR09: derived from start/end, adjusted for overnight intervals.
    public int DurationMinutes { get; set; }

    // Self-reported quality 1..10 (optional, BR06/BR10).
    public int? PerceivedQuality { get; set; }
    public float? SleepEfficiency { get; set; }

    public string? Notes { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;

    public User? User { get; set; }
    public SleepFactor? Factor { get; set; }
    public SleepMetric? Metric { get; set; }
}
