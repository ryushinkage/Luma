namespace SleepAnalytics.Api.Domain.Entities;

// BR14: behavioral factors that may influence sleep quality.
public class SleepFactor
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid SleepRecordId { get; set; }

    public bool Caffeine { get; set; }
    public int? StressLevel { get; set; }            // 1..10
    public int? ScreenTimeMinutes { get; set; }
    public int? PhysicalActivityMinutes { get; set; }
    public string? Notes { get; set; }

    public SleepRecord? SleepRecord { get; set; }
}
