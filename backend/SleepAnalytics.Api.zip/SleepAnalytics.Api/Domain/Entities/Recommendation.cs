using SleepAnalytics.Api.Domain.Enums;

namespace SleepAnalytics.Api.Domain.Entities;

// BR19: personalized recommendations.
public class Recommendation
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid ReportId { get; set; }

    public string Title { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public RecommendationType Type { get; set; }
    public int Priority { get; set; }

    public AIReport? Report { get; set; }
}
