namespace SleepAnalytics.Api.Domain.Entities;

public class UserProfile
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid UserId { get; set; }

    public string? SleepGoal { get; set; }

    // BR12: default sleep target used until the user configures a personal one.
    public int TargetSleepMinutes { get; set; } = 480; // 8h default
    public TimeOnly? PreferredSleepTime { get; set; }
    public TimeOnly? PreferredWakeTime { get; set; }

    // Used to interpret overnight sleep dates (BR07).
    public string TimeZoneId { get; set; } = "UTC";

    public User? User { get; set; }
}
