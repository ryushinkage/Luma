using SleepAnalytics.Api.Domain.Enums;

namespace SleepAnalytics.Api.Domain.Entities;

public class Subscription
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid UserId { get; set; }

    public PlanType PlanType { get; set; } = PlanType.Free;
    public SubscriptionStatus Status { get; set; } = SubscriptionStatus.Active;
    public DateTime? ExpiresAt { get; set; }

    // BR24: store payment reference for entitlement checks.
    public string? PaymentReference { get; set; }

    public User? User { get; set; }

    // BR23/BR25: Premium is active only while status = Active and not expired.
    public bool IsPremium() =>
        PlanType == PlanType.Premium
        && Status == SubscriptionStatus.Active
        && (ExpiresAt == null || ExpiresAt > DateTime.UtcNow);
}
