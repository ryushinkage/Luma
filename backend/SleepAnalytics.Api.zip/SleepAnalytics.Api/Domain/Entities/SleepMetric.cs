namespace SleepAnalytics.Api.Domain.Entities;

// BR08/BR09/BR11/BR12: derived metrics recalculated when a record changes.
public class SleepMetric
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid SleepRecordId { get; set; }

    public float? RegularityScore { get; set; }
    public int SleepDebtMinutes { get; set; }
    public float? QualityScore { get; set; }
    public float? EfficiencyScore { get; set; }

    // BR10: mark results as limited when important source metrics are missing.
    public bool IsLimited { get; set; }

    public SleepRecord? SleepRecord { get; set; }
}
