namespace SleepAnalytics.Api.Domain.Entities;

// BR29: admin-managed recommendation content / insight rules.
public class RecommendationRule
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Condition { get; set; } = string.Empty;
    public string Action { get; set; } = string.Empty;
    public bool Active { get; set; } = true;
}
