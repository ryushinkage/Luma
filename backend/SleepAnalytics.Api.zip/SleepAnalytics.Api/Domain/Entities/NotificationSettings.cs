namespace SleepAnalytics.Api.Domain.Entities;

public class NotificationSettings
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid UserId { get; set; }

    // BR26: push only when enabled and permission granted.
    public bool PushEnabled { get; set; }
    public TimeOnly? ReminderTime { get; set; }
    public bool SmartRemindersEnabled { get; set; }

    public User? User { get; set; }
}
