using SleepAnalytics.Api.Domain.Enums;

namespace SleepAnalytics.Api.Domain.Entities;

public class User
{
    public Guid Id { get; set; } = Guid.NewGuid();

    // BR01: Google account identifier is the stable external identity key.
    public string GoogleSubjectId { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;

    // BR02: every newly created account receives the User role by default.
    public UserRole Role { get; set; } = UserRole.User;

    public bool IsBlocked { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    // Navigation
    public UserProfile? Profile { get; set; }
    public Subscription? Subscription { get; set; }
    public NotificationSettings? NotificationSettings { get; set; }
    public ICollection<SleepRecord> SleepRecords { get; set; } = new List<SleepRecord>();
    public ICollection<AIReport> AIReports { get; set; } = new List<AIReport>();
}
