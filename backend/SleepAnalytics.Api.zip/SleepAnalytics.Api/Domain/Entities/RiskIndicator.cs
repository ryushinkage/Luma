using SleepAnalytics.Api.Domain.Enums;

namespace SleepAnalytics.Api.Domain.Entities;

// BR17/BR21: risk screening framed as indicators, never as a diagnosis.
public class RiskIndicator
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid ReportId { get; set; }

    public string RiskType { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public RiskLevel Level { get; set; }

    public AIReport? Report { get; set; }
}
