# Sleep Analytics — Backend (ASP.NET Core)

Стартовый каркас бэкенда для проекта Sleep Analytics.
Простая многослойная архитектура в одном проекте: `Domain` → `Infrastructure` → `Application` → `Api`.

## Стек
- .NET 8 / ASP.NET Core Web API
- EF Core + PostgreSQL (Npgsql)
- JWT-аутентификация
- Swagger (в Development)

## Структура
- `Domain/` — сущности и enum'ы (по class- и object-диаграммам).
- `Infrastructure/Persistence/` — `AppDbContext` (EF Core).
- `Infrastructure/Integrations/` — интерфейсы внешних сервисов и заглушки
  (Google OAuth, PayPal, AI API, Push). Реальные реализации подключаются позже.
- `Application/` — DTO и сервисы с бизнес-логикой.
- `Api/Controllers/` — REST-эндпоинты.

## Реализованные бизнес-правила (фрагмент)
- BR01/BR02 — вход через Google OAuth, роль User по умолчанию (`AuthService`).
- BR03/BR04/BR05 — авторизация, изоляция данных пользователя, ограничение Admin.
- BR06/BR07 — создание и валидация записи сна.
- BR08/BR09/BR12 — пересчёт метрик, расчёт длительности и sleep debt.
- BR23/BR25 — `Subscription.IsPremium()`.
- BR28 — управление пользователями в `AdminController`.

Остальные правила (BR10–BR33) оставлены как точки расширения в соответствующих
сервисах/сущностях с комментариями.

## Запуск
```bash
# 1. Поднять PostgreSQL и указать строку подключения в appsettings.json
# 2. Установить EF CLI (один раз)
dotnet tool install --global dotnet-ef

# 3. Создать и применить миграцию
dotnet ef migrations add InitialCreate
dotnet ef database update

# 4. Запуск
dotnet run
# Swagger: https://localhost:7001/swagger
```

## Заметки
- Интеграции реализованы как stub-классы (`Stub*`) — замените их на реальные
  вызовы SDK, зарегистрировав другую реализацию в `Program.cs`.
- Перед продакшеном замените `Jwt:Key` и не храните секреты в `appsettings.json`.
