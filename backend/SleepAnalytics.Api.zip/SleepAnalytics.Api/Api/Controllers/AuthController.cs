using Microsoft.AspNetCore.Mvc;
using SleepAnalytics.Api.Application.Dtos;
using SleepAnalytics.Api.Application.Services;

namespace SleepAnalytics.Api.Api.Controllers;

[ApiController]
[Route("api/auth")]
public class AuthController : ControllerBase
{
    private readonly IAuthService _auth;
    public AuthController(IAuthService auth) => _auth = auth;

    // BR01: login/registration via Google OAuth only.
    [HttpPost("google")]
    public async Task<IActionResult> Google([FromBody] GoogleLoginRequest request, CancellationToken ct)
    {
        var result = await _auth.LoginWithGoogleAsync(request, ct);
        return result.Succeeded ? Ok(result.Value) : Unauthorized(new { error = result.Error });
    }
}
