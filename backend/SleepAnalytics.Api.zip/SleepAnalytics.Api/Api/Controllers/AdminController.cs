using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SleepAnalytics.Api.Infrastructure.Persistence;

namespace SleepAnalytics.Api.Api.Controllers;

// BR05: administrative functions restricted to the Admin role (server-side check).
[ApiController]
[Authorize(Roles = "Admin")]
[Route("api/admin")]
public class AdminController : ControllerBase
{
    private readonly AppDbContext _db;
    public AdminController(AppDbContext db) => _db = db;

    // BR28: view users and subscription state.
    [HttpGet("users")]
    public async Task<IActionResult> Users(CancellationToken ct)
    {
        var users = await _db.Users
            .Select(u => new
            {
                u.Id, u.Email, u.Name, Role = u.Role.ToString(), u.IsBlocked,
                Plan = u.Subscription != null ? u.Subscription.PlanType.ToString() : "Free"
            })
            .ToListAsync(ct);
        return Ok(users);
    }

    // BR28: block / restore a user.
    [HttpPost("users/{id:guid}/block")]
    public async Task<IActionResult> Block(Guid id, [FromQuery] bool blocked, CancellationToken ct)
    {
        var user = await _db.Users.FindAsync(new object?[] { id }, ct);
        if (user is null) return NotFound();
        user.IsBlocked = blocked;
        await _db.SaveChangesAsync(ct);
        return Ok(new { user.Id, user.IsBlocked });
    }
}
