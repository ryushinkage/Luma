using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SleepAnalytics.Api.Application.Dtos;
using SleepAnalytics.Api.Application.Services;

namespace SleepAnalytics.Api.Api.Controllers;

// BR03: all endpoints require an authenticated session.
[ApiController]
[Authorize]
[Route("api/sleep-records")]
public class SleepRecordsController : ControllerBase
{
    private readonly ISleepRecordService _service;
    public SleepRecordsController(ISleepRecordService service) => _service = service;

    private Guid CurrentUserId =>
        Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)
                   ?? User.FindFirstValue("sub")!);

    [HttpGet]
    public async Task<IActionResult> List([FromQuery] DateOnly? from, [FromQuery] DateOnly? to, CancellationToken ct)
        => Ok(await _service.ListAsync(CurrentUserId, from, to, ct));

    [HttpGet("stats")]
    public async Task<IActionResult> Stats([FromQuery] DateOnly from, [FromQuery] DateOnly to, CancellationToken ct)
        => Ok(await _service.GetStatsAsync(CurrentUserId, from, to, ct));

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateSleepRecordRequest req, CancellationToken ct)
    {
        var result = await _service.CreateAsync(CurrentUserId, req, ct);
        return result.Succeeded
            ? CreatedAtAction(nameof(List), new { }, result.Value)
            : BadRequest(new { error = result.Error });   // BR07 validation
    }

    [HttpPut("{id:guid}")]
    public async Task<IActionResult> Update(Guid id, [FromBody] UpdateSleepRecordRequest req, CancellationToken ct)
    {
        var result = await _service.UpdateAsync(CurrentUserId, id, req, ct);
        return result.Succeeded ? Ok(result.Value) : BadRequest(new { error = result.Error });
    }

    [HttpDelete("{id:guid}")]
    public async Task<IActionResult> Delete(Guid id, CancellationToken ct)
    {
        var result = await _service.DeleteAsync(CurrentUserId, id, ct);
        return result.Succeeded ? NoContent() : NotFound(new { error = result.Error });
    }
}
