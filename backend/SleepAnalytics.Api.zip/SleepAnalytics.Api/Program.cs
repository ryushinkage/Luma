using System.Text;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using SleepAnalytics.Api.Application.Services;
using SleepAnalytics.Api.Infrastructure.Integrations;
using SleepAnalytics.Api.Infrastructure.Persistence;

var builder = WebApplication.CreateBuilder(args);

// ---- Persistence (BR04/BR30: PostgreSQL) ----
builder.Services.AddDbContext<AppDbContext>(opt =>
    opt.UseNpgsql(builder.Configuration.GetConnectionString("Postgres")));

// ---- Application services ----
builder.Services.AddScoped<ITokenService, JwtTokenService>();
builder.Services.AddScoped<IAuthService, AuthService>();
builder.Services.AddScoped<ISleepRecordService, SleepRecordService>();

// ---- Integration stubs (swap for real implementations later) ----
builder.Services.AddScoped<IGoogleAuthService, StubGoogleAuthService>();
builder.Services.AddScoped<IPaymentService, StubPaymentService>();
builder.Services.AddScoped<IAiService, StubAiService>();
builder.Services.AddScoped<IPushNotificationService, StubPushNotificationService>();

// ---- Auth (BR03/BR05) ----
var jwt = builder.Configuration.GetSection("Jwt");
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(opt =>
    {
        opt.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer = jwt["Issuer"],
            ValidAudience = jwt["Audience"],
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwt["Key"]!))
        };
    });
builder.Services.AddAuthorization();

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();

app.Run();
